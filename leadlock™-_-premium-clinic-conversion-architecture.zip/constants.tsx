
import { Feature, Bonus, ComparisonRow, FAQItem, Testimonial } from './types';

export const PRIMARY_FEATURES: Feature[] = [
  {
    id: 1,
    title: "Instant Auto Replies (24/7)",
    subheadline: "Immediate Engagement",
    description: "Every inquiry receives a professional response in under 5 seconds, 24/7, securing intent before competitors can.",
    benefit: "Convert up to 21× more leads by responding instantly.",
    messages: [
      { sender: 'patient', text: "Hi, what’s the cost of lip fillers?", time: "11:42 PM" },
      { 
        sender: 'system', 
        text: "Lip fillers range between ₹28,000–₹45,000. Would you like to book a consultation?", 
        time: "11:42 PM",
        buttons: ["Explain Options", "Book Consultation"]
      }
    ]
  },
  {
    id: 2,
    title: "90-Second Self-Booking",
    subheadline: "Zero-Friction Scheduling",
    description: "Patients view real-time availability and confirm appointments inside WhatsApp—no phone calls required.",
    benefit: "Reduces booking drop-offs by up to 50% through friction-free scheduling.",
    messages: [
      { 
        sender: 'system', 
        text: "Choose a slot with Dr. Ananya:", 
        time: "10:15 AM",
        buttons: ["Tomorrow 4:00 PM", "Thursday 11:00 AM", "Saturday 2:30 PM"]
      },
      { sender: 'patient', text: "Tomorrow 4:00 PM", time: "10:16 AM" },
      { sender: 'system', text: "✔ Consultation confirmed. See you then!", time: "10:16 AM" }
    ]
  },
  {
    id: 3,
    title: "Ghost Lead Recovery",
    subheadline: "Revenue Reclamation",
    description: "Automatically re-engage dormant inquiries with gentle, human-like nudges that revive old leads.",
    benefit: "Recover 1 in 20 dormant leads without spending more on ads.",
    messages: [
      { 
        sender: 'system', 
        text: "Hi Anjali, just checking in 😊 Would you like updated pricing for PRP?", 
        time: "Tuesday 9:00 AM",
        buttons: ["Yes, share details", "Not right now"]
      }
    ]
  },
  {
    id: 4,
    title: "Automated Reminders",
    subheadline: "Attendance Logic",
    description: "Automated 24h and 2h reminders let patients confirm or reschedule with one tap.",
    benefit: "Reduces no-shows by 40% on average.",
    messages: [
      { 
        sender: 'system', 
        text: "Reminder: You’re scheduled for tomorrow at 11:00 AM. Confirm or reschedule?", 
        time: "9:00 AM",
        buttons: ["Confirm", "Reschedule"]
      },
      { sender: 'patient', text: "Confirm", time: "9:05 AM" }
    ]
  }
];

export const EXPANDED_FEATURES: Feature[] = [
  {
    id: 5,
    title: "Smart Qualification",
    subheadline: "Time Protection",
    description: "Identifies budget and urgency automatically so staff only talk to 'Ready to Book' leads.",
    benefit: "Cuts wasted staff conversations by 70%.",
    messages: [
      { 
        sender: 'system', 
        text: "When are you planning to start your treatment?", 
        time: "2:00 PM",
        buttons: ["Researching", "This month", "This week"]
      }
    ]
  },
  {
    id: 6,
    title: "Unified Pipeline",
    subheadline: "Total Command",
    description: "Track every lead journey and total pipeline value from a single clinical dashboard.",
    benefit: "100% visibility into your lead conversion cycle.",
    isDashboard: true,
    messages: [
      { sender: 'tag', text: "PIPELINE SUMMARY", time: "NOW" },
      { sender: 'system', text: "• Active: 24\n• High Urgency: 6\n• Value: ₹1,45,000", time: "NOW" }
    ]
  }
];

export const BONUSES: Bonus[] = [
  {
    id: 'b1',
    title: "WhatsApp Analytics",
    summary: "Performance summaries.",
    description: "Receive concise conversion health reports every Sunday directly on WhatsApp.",
    bullets: ["Inquiries vs Bookings", "Revenue Pipeline Estimates"],
    impact: "Owner visibility in under 30 seconds.",
    visual: {
      type: 'whatsapp',
      messages: [
        { sender: 'tag', text: "WEEKLY SUMMARY", time: "SUN 9:00 AM" },
        { sender: 'system', text: "Inquiries: 84\nBookings: 22\nValue: ₹3,40,000", time: "9:01 AM" }
      ]
    }
  },
  {
    id: 'b2',
    title: "Staff Training & SOPs",
    summary: "Staff mastery.",
    description: "Full handover with walkthrough videos and workflows to ensure your team is ready day one.",
    bullets: ["Step-by-step SOP PDF", "Staff training video"],
    impact: "Reduces staff dependency by 60%.",
    visual: { type: 'document' }
  },
  {
    id: 'b3',
    title: "Upsell Sequences",
    summary: "LTV Automation.",
    description: "Automated suggestions for complementary treatments based on patient history.",
    bullets: ["Botox → Filler suggestions", "Smart timing logic"],
    impact: "Increases order value by up to 40%.",
    visual: {
      type: 'whatsapp',
      messages: [
        { sender: 'system', text: "Hi Sarah, patients who enjoy Botox often combine it with our Skin Booster. Interested?", time: "10:00 AM", buttons: ["Show Bundle", "Later"] }
      ]
    }
  },
  {
    id: 'b4',
    title: "Monthly Optimization",
    summary: "System growth.",
    description: "Continuous optimization of flows based on your specific patient interaction data.",
    bullets: ["Performance review calls", "A/B tested flows"],
    impact: "Continuous ROI improvement.",
    visual: { type: 'calendar' }
  }
];

export const COMPARISON_DATA: ComparisonRow[] = [
  {
    id: 1,
    title: "SPEED",
    bad: { 
      headline: "Hours-long delays", 
      explanation: "Leads cool off.", 
      outcome: "42% average drop-off as patients inquire elsewhere immediately." 
    },
    good: { 
      headline: "Sub-6s Reply", 
      explanation: "24/7 engagement.", 
      outcome: "94% of intent is locked within the first 6 seconds." 
    }
  },
  {
    id: 2,
    title: "BOOKING",
    bad: { 
      headline: "Manual scheduling", 
      explanation: "High drop-offs.", 
      outcome: "Staff friction leads to 35% abandonment during the 'check-calendar' phase." 
    },
    good: { 
      headline: "One-Tap Booking", 
      explanation: "Instant confirmation.", 
      outcome: "Patients book in <90 seconds without leaving the WhatsApp chat." 
    }
  },
  {
    id: 3,
    title: "NO-SHOWS",
    bad: { 
      headline: "Patients ghost", 
      explanation: "Revenue leakage.", 
      outcome: "Unconfirmed slots result in ₹45k+ lost weekly revenue for elite clinics." 
    },
    good: { 
      headline: "Auto Reminders", 
      explanation: "90%+ show-up rate.", 
      outcome: "Automated 24h nudge reduces cancellations by 68% on average." 
    }
  },
  {
    id: 4,
    title: "QUALITY",
    bad: { 
      headline: "Staff noise", 
      explanation: "Wasted time.", 
      outcome: "Team spends 12 hours/week answering 'price?' instead of closing." 
    },
    good: { 
      headline: "Qualification", 
      explanation: "Focus on buyers.", 
      outcome: "Pre-qualified high-value leads are delivered directly to staff for final closure." 
    }
  },
  {
    id: 5,
    title: "FOLLOW-UP",
    bad: { 
      headline: "Forgotten leads", 
      explanation: "Single contact point.", 
      outcome: "80% of leads that don't book immediately are never contacted again." 
    },
    good: { 
      headline: "Ghost Recovery", 
      explanation: "Multi-day nurture.", 
      outcome: "Smart logic revives 18% of cold inquiries after 72 hours of silence." 
    }
  },
  {
    id: 6,
    title: "DATA",
    bad: { 
      headline: "Blind marketing", 
      explanation: "Guessing ROI.", 
      outcome: "No visibility on which ads actually drive confirmed surgical consultations." 
    },
    good: { 
      headline: "Total Analytics", 
      explanation: "Precision tracking.", 
      outcome: "Weekly ROI reports showing exactly how much revenue was booked via WhatsApp." 
    }
  },
  {
    id: 7,
    title: "RETENTION",
    bad: { 
      headline: "One-off sales", 
      explanation: "Low LTV focus.", 
      outcome: "Patients forget the clinic name until they see a competitor's discount ad." 
    },
    good: { 
      headline: "Upsell Logic", 
      explanation: "Clinical longevity.", 
      outcome: "Automatic 3-month reminders for Botox/Skin boosters increase lifetime value." 
    }
  }
];

export const FAQ_DATA: FAQItem[] = [
  { id: 1, question: "Will this stop revenue leaks?", answer: "Yes. Every lead is engaged in 10s, 24/7, stopping the 40% loss common after hours." },
  { id: 2, question: "Will it look robotic?", answer: "No. Professional, instant replies build trust and look more premium than silence." },
  { id: 3, question: "Can it make mistakes?", answer: "No. All messages are pre-approved and fixed. There is no 'guessing'." },
  { id: 4, question: "Will it replace my staff?", answer: "No. It handles repetitive noise so your staff can focus on high-value closures." },
  { id: 5, question: "Is there a trial?", answer: "Yes. 30 days free to see the ROI in your practice first." }
];

export const TESTIMONIALS: Testimonial[] = [
  { id: 1, clinicName: "Radiance Skin", clinicInitials: "RS", message: "Leads get replies at night now. Huge time saver.", time: "10:15 PM" },
  { id: 2, clinicName: "Elite Hair", clinicInitials: "EH", message: "Patients book directly. Fewer 'thinking about it' messages.", time: "2:30 PM" },
  { id: 3, clinicName: "Verma Aesthetics", clinicInitials: "DV", message: "Reminders work. No-shows reduced significantly.", time: "9:00 AM" }
];
