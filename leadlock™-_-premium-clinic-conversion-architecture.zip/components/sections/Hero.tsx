
import React from 'react';
import { Reveal } from '../ui/Reveal';
import { scrollToSection } from '../../utils/scroll';

export const Hero: React.FC = () => {
  return (
    <section id="home" className="relative pt-24 pb-12 px-6 max-w-[1400px] mx-auto flex flex-col items-center bg-clinic-grid rounded-b-[3rem] border-b border-slate-100 overflow-hidden">
      <Reveal className="inline-flex items-center px-4 py-2 mb-8 rounded-full bg-slate-900 text-white text-[9px] font-bold tracking-[0.3em] uppercase">
        <span className="w-2 h-2 bg-emerald-400 rounded-full mr-2 animate-pulse"></span>
        Clinical Response Infrastructure
      </Reveal>
      <div className="relative text-center max-w-4xl mb-12">
        <Reveal delay={100}><h1 className="text-gradient text-5xl md:text-8xl font-bold mb-6 tracking-tighter leading-[0.95]">Stop the Silent Revenue Leak.</h1></Reveal>
        <Reveal delay={200}><p className="text-xl md:text-2xl text-slate-700 max-w-2xl mx-auto font-medium leading-relaxed">Don't let leads go cold. <span className="text-slate-900 font-bold border-b-2 border-emerald-400">LEADLOCK™</span> books consultations instantly—24/7.</p></Reveal>
      </div>

      <div className="relative w-full max-w-5xl grid md:grid-cols-2 gap-6 mb-12 px-4">
         <Reveal delay={300}>
           <div className="glass-panel h-full rounded-[2.5rem] p-10 flex flex-col justify-between border-slate-200 shadow-md">
              <div><p className="text-xs font-bold text-slate-800 uppercase tracking-widest mb-6 border-b border-slate-100 pb-2">Diagnostic: Manual</p>
              <div className="space-y-5">{["Inquiries ignored after hours", "Manual friction", "Leads cooling off"].map((text, i) => (<div key={i} className="flex items-center space-x-4"><div className="w-3 h-3 bg-red-500 rounded-full shrink-0"></div><p className="text-sm text-slate-700 font-semibold">{text}</p></div>))}</div></div>
              <div className="mt-8 pt-6 border-t border-slate-200"><p className="text-3xl font-serif text-slate-900 italic font-medium">42% Average <span className="text-red-600 font-bold">Loss</span></p></div>
           </div>
         </Reveal>
         <Reveal delay={400}>
           <div className="bg-slate-900 h-full rounded-[2.5rem] p-10 flex flex-col justify-between text-white relative overflow-hidden scanning-bar shadow-2xl">
              <div className="relative z-10"><p className="text-xs font-bold text-emerald-400 uppercase tracking-widest mb-6 border-b border-white/10 pb-2">Diagnostic: Optimized</p>
              <div className="space-y-5">{["Instant response (<6s)", "Self-service booking", "Automated recovery"].map((text, i) => (<div key={i} className="flex items-center space-x-4"><div className="w-3 h-3 bg-emerald-400 rounded-full shrink-0"></div><p className="text-sm text-white font-semibold">{text}</p></div>))}</div></div>
              <div className="relative z-10 mt-8 pt-6 border-t border-white/20"><p className="text-3xl font-serif text-white italic font-medium">94% Intent <span className="text-emerald-400 font-bold">Locked</span></p></div>
           </div>
         </Reveal>
      </div>

      <Reveal delay={500} className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6 w-full max-w-md">
        <button onClick={(e) => scrollToSection(e, 'offer')} className="w-full bg-slate-900 text-white px-10 py-5 rounded-full font-bold text-lg hover:bg-slate-800 transition-all cta-breath shadow-lg">Book Clarity Call</button>
        <button onClick={(e) => scrollToSection(e, 'faq')} className="w-full bg-white border-2 border-slate-900 text-slate-900 px-10 py-5 rounded-full font-bold text-lg hover:bg-slate-50 transition-all shadow-md">WhatsApp Consult</button>
      </Reveal>
    </section>
  );
};
