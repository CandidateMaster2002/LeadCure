
import React from 'react';
import { Reveal } from '../ui/Reveal';

const PATH_STEPS = [
  { label: "Lead", icon: "👤", sub: "Ad / Search" },
  { label: "Reply", icon: "💬", sub: "Instant <5s" },
  { label: "Book", icon: "📅", sub: "Auto-Sched" },
  { label: "Remind", icon: "🔔", sub: "Zero No-Show" },
  { label: "Result", icon: "🏥", sub: "Rev locked" }
];

export const PrecisionPath: React.FC = () => {
  return (
    <section className="py-20 bg-white overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6">
        <Reveal className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold tracking-tight text-slate-900">The Precision Path.</h2>
        </Reveal>
        <div className="relative flex flex-col md:flex-row items-center justify-between gap-8 md:gap-2">
          {PATH_STEPS.map((step, i, arr) => (
            <React.Fragment key={i}>
              <Reveal delay={i * 100} className="flex-1 w-full max-w-[200px] relative z-10">
                <div className="flex flex-col items-center text-center group">
                  <div className="w-20 h-20 rounded-3xl bg-white border-2 border-slate-100 flex items-center justify-center text-3xl mb-4 shadow-sm relative group-hover:border-emerald-400 group-hover:shadow-emerald-100 transition-all duration-300">
                    {step.icon}
                    <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-slate-900 text-white text-[10px] font-bold flex items-center justify-center shadow-lg">
                      0{i + 1}
                    </div>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1 uppercase tracking-tight">{step.label}</h4>
                  <p className="text-[11px] text-slate-600 font-semibold leading-tight max-w-[120px]">{step.sub}</p>
                </div>
              </Reveal>
              {i < arr.length - 1 && (
                <div className="flex items-center text-emerald-500 flex-shrink-0 animate-pulse-slow py-4 md:py-0">
                  <svg className="w-8 h-8 rotate-90 md:rotate-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M9 5l7 7-7 7"/>
                  </svg>
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    </section>
  );
};
