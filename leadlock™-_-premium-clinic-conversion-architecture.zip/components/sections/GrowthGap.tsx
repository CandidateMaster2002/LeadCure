
import React, { useState } from 'react';
import { Reveal } from '../ui/Reveal';
import { COMPARISON_DATA } from '../../constants';

export const GrowthGap: React.FC = () => {
  const [showAll, setShowAll] = useState(false);
  const [activeId, setActiveId] = useState<number | null>(null);

  const toggleComparison = (id: number) => setActiveId(activeId === id ? null : id);
  const comparisonToShow = showAll ? COMPARISON_DATA : COMPARISON_DATA.slice(0, 4);

  return (
    <section id="gap" className="bg-white py-24">
      <div className="max-w-[1100px] mx-auto px-6">
        <Reveal className="text-center mb-16"><h2 className="text-5xl md:text-8xl font-bold tracking-tight font-serif italic text-slate-900">The Growth Gap.</h2></Reveal>
        <Reveal className="bg-white rounded-[3rem] shadow-2xl overflow-hidden border-2 border-slate-100">
          <div className="grid grid-cols-2 text-center text-[10px] md:text-xs font-bold tracking-widest uppercase">
            <div className="py-8 bg-slate-50 border-r border-slate-200 text-slate-600">Manual Operations ⚠️</div>
            <div className="py-8 bg-slate-900 text-white flex items-center justify-center space-x-3"><span>LEADLOCK™</span><span className="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-pulse shadow-[0_0_10px_rgba(52,211,153,0.8)]"></span></div>
          </div>
          <div className="divide-y-2 divide-slate-100">
            {comparisonToShow.map((row) => (
              <div key={row.id} className="flex flex-col">
                <button 
                  onClick={() => toggleComparison(row.id)}
                  className="grid grid-cols-2 group hover:bg-slate-50 transition-all duration-300 text-left relative"
                >
                  <div className="p-8 md:p-12 border-r-2 border-slate-100">
                    <h4 className="font-bold text-slate-900 mb-3 uppercase text-sm tracking-widest flex items-center"><span className="w-2 h-2 bg-red-500 rounded-full mr-3 shrink-0"></span>{row.bad.headline}</h4>
                    <p className="text-slate-700 font-medium text-base leading-relaxed">{row.bad.explanation}</p>
                  </div>
                  <div className="p-8 md:p-12 bg-emerald-50/20">
                    <h4 className="font-bold text-emerald-700 mb-3 uppercase text-sm tracking-widest flex items-center"><span className="w-2 h-2 bg-emerald-500 rounded-full mr-3 shrink-0"></span>{row.good.headline}</h4>
                    <p className="text-slate-900 font-semibold text-base leading-relaxed">{row.good.explanation}</p>
                  </div>
                  <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-400 transition-all shadow-md group-hover:scale-110 ${activeId === row.id ? 'rotate-180 bg-slate-900 text-white border-slate-900' : ''}`}>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M19 9l-7 7-7-7"/></svg>
                  </div>
                </button>
                <div className={`overflow-hidden transition-all duration-500 bg-slate-50 border-t border-slate-100 ${activeId === row.id ? 'max-h-[300px] opacity-100' : 'max-h-0 opacity-0'}`}>
                  <div className="grid grid-cols-2 divide-x-2 divide-slate-200">
                    <div className="p-8 pt-4">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Revenue Impact</p>
                      <p className="text-sm text-red-600 font-bold italic">{row.bad.outcome}</p>
                    </div>
                    <div className="p-8 pt-4">
                      <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest mb-2">The LeadLock Advantage</p>
                      <p className="text-sm text-slate-900 font-bold">{row.good.outcome}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Reveal>
        
        {!showAll && (
          <Reveal className="flex justify-center mt-12">
            <button 
              onClick={() => setShowAll(true)}
              className="bg-white border-2 border-slate-900 text-slate-950 px-10 py-4 rounded-full font-bold text-xs uppercase tracking-widest hover:bg-slate-900 hover:text-white transition-all shadow-lg active:scale-95"
            >
              View Full Comparison Matrix ↓
            </button>
          </Reveal>
        )}
      </div>
    </section>
  );
};
