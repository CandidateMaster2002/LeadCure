
import React, { useState } from 'react';
import { Reveal } from '../ui/Reveal';
import { PRIMARY_FEATURES, EXPANDED_FEATURES } from '../../constants';
import WhatsAppMockup from '../WhatsAppMockup';
import { Feature } from '../../types';

export const Protocols: React.FC = () => {
  const [showAll, setShowAll] = useState(false);

  const renderProtocolItem = (feature: Feature, idx: number) => (
    <Reveal key={feature.id} delay={idx % 2 === 0 ? 0 : 100} className="flex flex-col xl:flex-row items-start gap-10 group">
      <div className="flex-1 space-y-6">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl bg-slate-900 flex items-center justify-center text-white font-serif text-xl border border-slate-800 transition-all">0{feature.id}</div>
          <span className="text-xs font-bold tracking-[0.2em] uppercase text-emerald-600">Active Protocol</span>
        </div>
        <h3 className="text-3xl md:text-5xl font-bold tracking-tight text-slate-900 group-hover:text-emerald-700 transition-colors leading-tight">{feature.title}</h3>
        <p className="text-lg text-slate-700 font-medium leading-relaxed">{feature.description}</p>
        <div className="p-5 bg-emerald-50 border-l-4 border-emerald-400 rounded-r-2xl">
          <p className="text-emerald-900 font-semibold text-sm leading-snug">{feature.benefit}</p>
        </div>
      </div>
      <div className="w-full xl:w-auto flex-shrink-0 flex justify-center">
        <div className="scale-[0.6] sm:scale-[0.75] xl:scale-[0.8] -my-24 xl:-my-16">
          <WhatsAppMockup messages={feature.messages} />
        </div>
      </div>
    </Reveal>
  );

  return (
    <section id="protocols" className="max-w-[1400px] mx-auto px-6 py-20 bg-slate-50 rounded-[4rem]">
      <Reveal className="mb-20 text-center">
        <h2 className="text-5xl md:text-8xl font-bold tracking-tight text-slate-900">System Protocols.</h2>
      </Reveal>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-x-12 gap-y-24">
        {PRIMARY_FEATURES.map((feature, idx) => renderProtocolItem(feature, idx))}
        {showAll && EXPANDED_FEATURES.map((feature, idx) => renderProtocolItem(feature, idx + PRIMARY_FEATURES.length))}
      </div>
      {!showAll && (
        <Reveal className="flex justify-center mt-20">
          <button 
            onClick={() => setShowAll(true)} 
            className="bg-slate-900 text-white px-10 py-5 rounded-full font-bold text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl active:scale-95"
          >
            View Advanced Protocols ↓
          </button>
        </Reveal>
      )}
    </section>
  );
};
