
import React, { useState, useEffect, useRef } from 'react';
import { Reveal } from '../ui/Reveal';
import { TESTIMONIALS } from '../../constants';

export const Outcomes: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!scrollRef.current) return;
      const scrollLeft = scrollRef.current.scrollLeft;
      const width = scrollRef.current.offsetWidth;
      const index = Math.round(scrollLeft / width);
      if (index !== activeIndex) {
        setActiveIndex(index);
      }
    };

    const container = scrollRef.current;
    if (container) {
      container.addEventListener('scroll', handleScroll, { passive: true });
    }
    return () => container?.removeEventListener('scroll', handleScroll);
  }, [activeIndex]);

  return (
    <section id="outcomes" className="bg-white py-24 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6">
        <Reveal className="mb-16"><h2 className="text-5xl md:text-8xl font-bold tracking-tight font-serif italic text-slate-900">Proven Outcomes.</h2></Reveal>
        
        <div className="relative">
          <div 
            ref={scrollRef}
            className="flex space-x-6 overflow-x-auto pb-12 no-scrollbar snap-x snap-mandatory"
            style={{ paddingRight: '20%' }}
          >
            {TESTIMONIALS.map((t, idx) => (
              <Reveal key={t.id} delay={idx * 100} className="shrink-0 snap-start">
                <div className="bg-slate-50 p-8 md:p-10 rounded-[3rem] w-[300px] sm:w-[360px] md:w-[450px] border-2 border-slate-100 shadow-sm hover:shadow-xl transition-all duration-500 hover:-translate-y-2">
                  <div className="mb-6 flex text-emerald-500">
                    {[1,2,3,4,5].map(s => <svg key={s} className="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>)}
                  </div>
                  <p className="text-slate-900 text-base md:text-xl font-semibold italic mb-8 leading-relaxed">"{t.message}"</p>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-slate-900 text-white rounded-2xl flex items-center justify-center font-bold">{t.clinicInitials}</div>
                    <div>
                      <p className="font-bold text-slate-900 text-base">{t.clinicName}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Verified Practice</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
          
          <div className="flex justify-center items-center space-x-3 mt-4">
            {TESTIMONIALS.map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  scrollRef.current?.scrollTo({
                    left: idx * (scrollRef.current.offsetWidth * 0.8), 
                    behavior: 'smooth'
                  });
                }}
                className={`h-2 rounded-full transition-all duration-300 ${
                  activeIndex === idx 
                    ? 'w-8 bg-slate-900' 
                    : 'w-2 bg-slate-200 hover:bg-slate-400'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
