
import React from 'react';
import { Reveal } from '../ui/Reveal';

export const Offer: React.FC = () => {
  return (
    <section id="offer" className="py-24 bg-white">
      <div className="max-w-[1200px] mx-auto px-6">
        <Reveal className="bg-slate-900 rounded-[4rem] p-12 md:p-28 text-center text-white relative overflow-hidden shadow-2xl border-b-[12px] border-emerald-500">
          <div className="relative z-10 space-y-12">
            <Reveal delay={100} className="space-y-6">
              <p className="text-xs font-bold text-emerald-400 uppercase tracking-[0.4em]">Strategic Partnership Opportunity</p>
              <h2 className="text-6xl md:text-[10rem] font-bold tracking-tighter leading-none font-serif italic mb-4">30 DAYS FREE.</h2>
              <p className="text-2xl md:text-4xl text-slate-200 font-medium italic">Zero upfront costs. Performance focus.</p>
            </Reveal>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-4">
              <button className="w-full sm:w-auto bg-white text-slate-900 px-12 py-6 rounded-full font-bold text-xl hover:scale-105 transition-all shadow-[0_20px_40px_rgba(255,255,255,0.1)] active:scale-95">📅 Book 15m Clarity Call</button>
              <button className="w-full sm:w-auto bg-emerald-500 text-white px-12 py-6 rounded-full font-bold text-xl hover:scale-105 transition-all shadow-[0_20px_40px_rgba(16,185,129,0.3)] active:scale-95">WhatsApp Consultation</button>
            </div>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-widest pt-8">Strictly 3 Clinics Per Quarter to Maintain Precision</p>
          </div>
        </Reveal>
      </div>
    </section>
  );
};
