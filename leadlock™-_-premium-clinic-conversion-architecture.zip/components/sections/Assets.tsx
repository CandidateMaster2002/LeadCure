
import React, { useState } from 'react';
import { Reveal } from '../ui/Reveal';
import { BONUSES } from '../../constants';
import { Bonus } from '../../types';

export const Assets: React.FC = () => {
  const [showAll, setShowAll] = useState(false);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({ [BONUSES[0].id]: false, [BONUSES[1].id]: false });

  const toggleBonus = (id: string) => setCollapsed(prev => ({ ...prev, [id]: !prev[id] }));

  const renderBonusItem = (bonus: Bonus, index: number) => {
    const isCollapsed = collapsed[bonus.id] ?? true;
    return (
      <Reveal key={bonus.id} delay={index * 150}>
        <div className="bg-white border border-slate-200 rounded-[2rem] overflow-hidden transition-all hover:border-emerald-200 h-full flex flex-col group shadow-sm hover:shadow-md">
          <button onClick={() => toggleBonus(bonus.id)} className="w-full p-6 flex items-center justify-between group text-left transition-colors bg-white">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-xl group-hover:bg-emerald-50 transition-all">{bonus.id === 'b1' ? '📊' : bonus.id === 'b2' ? '👨‍⚕️' : bonus.id === 'b3' ? '🚀' : '📅'}</div>
              <h3 className="text-base font-semibold text-slate-900 group-hover:text-emerald-600 transition-colors">{bonus.title}</h3>
            </div>
            <span className={`w-6 h-6 rounded-full border border-slate-200 flex items-center justify-center text-slate-700 transition-all ${!isCollapsed ? 'rotate-180 bg-slate-900 text-white' : ''}`}><svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" /></svg></span>
          </button>
          <div className={`transition-all duration-500 ease-in-out flex-1 overflow-hidden ${!isCollapsed ? 'max-h-[800px] opacity-100 p-6 pt-0' : 'max-h-0 opacity-0 p-0'}`}>
            <div className="space-y-4">
              <p className="text-sm text-slate-700 font-normal leading-snug">{bonus.description}</p>
              <ul className="space-y-2">
                {bonus.bullets.map((bullet, bIdx) => (
                  <li key={bIdx} className="flex items-start space-x-2 text-slate-800 text-xs font-medium">
                    <div className="w-4 h-4 bg-emerald-100 rounded-full flex items-center justify-center mt-0.5 shrink-0"><svg className="w-2.5 h-2.5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg></div>
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>
              <p className="text-slate-900 font-bold text-xs leading-snug border-l-4 border-slate-900 pl-4 py-1 bg-slate-50">{bonus.impact}</p>
            </div>
          </div>
        </div>
      </Reveal>
    );
  };

  return (
    <section className="bg-slate-50 py-24 rounded-[5rem]">
      <div className="max-w-[1200px] mx-auto px-6">
        <Reveal className="mb-16 text-center"><h2 className="text-5xl md:text-8xl font-bold tracking-tight text-slate-900">System Assets.</h2></Reveal>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {BONUSES.slice(0, 2).map((bonus, idx) => renderBonusItem(bonus, idx))}
          {showAll && BONUSES.slice(2, 4).map((bonus, idx) => renderBonusItem(bonus, idx + 2))}
        </div>
        {!showAll && (
          <Reveal className="flex justify-center mt-16">
            <button onClick={() => setShowAll(true)} className="bg-white border-2 border-slate-900 text-slate-900 px-8 py-4 rounded-full font-bold text-xs uppercase tracking-widest hover:bg-slate-900 hover:text-white transition-all shadow-lg active:scale-95">Unlock Extended Assets ↓</button>
          </Reveal>
        )}
      </div>
    </section>
  );
};
