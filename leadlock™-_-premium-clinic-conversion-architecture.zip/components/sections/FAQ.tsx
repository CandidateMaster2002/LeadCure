
import React, { useState } from 'react';
import { Reveal } from '../ui/Reveal';
import { FAQ_DATA } from '../../constants';

export const FAQ: React.FC = () => {
  const [showAll, setShowAll] = useState(false);
  const [activeId, setActiveId] = useState<number | null>(null);

  const toggleFaq = (id: number) => setActiveId(activeId === id ? null : id);

  return (
    <section id="faq" className="bg-white py-24">
      <div className="max-w-[850px] mx-auto px-6">
        <Reveal className="text-center mb-16"><h2 className="text-4xl md:text-6xl font-bold font-serif italic text-slate-900 tracking-tight">System Inquiries.</h2></Reveal>
        <div className="space-y-4">
          {(showAll ? FAQ_DATA : FAQ_DATA.slice(0, 3)).map((faq, idx) => (
            <Reveal key={faq.id} delay={idx * 50}>
              <div className="bg-slate-50 border-2 border-slate-100 rounded-[2rem] overflow-hidden shadow-sm hover:border-emerald-200 transition-colors">
                <button onClick={() => toggleFaq(faq.id)} className="w-full p-8 text-left flex items-center justify-between group">
                  <span className={`text-base md:text-lg font-bold transition-colors ${activeId === faq.id ? 'text-emerald-700' : 'text-slate-900'}`}>{faq.question}</span>
                  <svg className={`w-6 h-6 text-slate-400 transition-transform duration-300 ${activeId === faq.id ? 'rotate-180 text-emerald-600' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M19 9l-7 7-7-7" /></svg>
                </button>
                <div className={`transition-all duration-300 overflow-hidden ${activeId === faq.id ? 'max-h-[300px] opacity-100' : 'max-h-0 opacity-0'}`}>
                  <div className="p-8 pt-0 text-slate-800 text-base font-medium leading-relaxed border-t border-slate-200 mt-2">{faq.answer}</div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
        {!showAll && (
          <Reveal className="flex justify-center mt-12">
            <button onClick={() => setShowAll(true)} className="bg-slate-900 text-white px-8 py-4 rounded-full font-bold text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg active:scale-95">View More Inquiries ↓</button>
          </Reveal>
        )}
      </div>
    </section>
  );
};
