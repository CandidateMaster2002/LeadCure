
import React, { useState, useEffect } from 'react';
import { scrollToSection } from '../../utils/scroll';

const NAV_ITEMS = [
  { label: 'Home', id: 'home' },
  { label: 'Protocols', id: 'protocols' },
  { label: 'Gap', id: 'gap' },
  { label: 'Outcomes', id: 'outcomes' },
  { label: 'FAQ', id: 'faq' },
  { label: 'Offer', id: 'offer' },
];

export const Header: React.FC = () => {
  const [activeSection, setActiveSection] = useState('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 120;
      for (const item of NAV_ITEMS) {
        const element = document.getElementById(item.id);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(item.id);
          }
        }
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className="fixed top-0 left-0 right-0 z-[100] bg-white border-b border-slate-100 px-4 md:px-8 shadow-sm">
      <div className="max-w-[1400px] mx-auto h-16 flex items-center justify-between">
        <a 
          href="#home" 
          onClick={(e) => scrollToSection(e, 'home')}
          className="text-lg font-serif italic font-bold tracking-tighter text-slate-900 shrink-0"
        >
          LEADLOCK™
        </a>
        
        <nav className="hidden lg:block absolute left-1/2 -translate-x-1/2">
          <ul className="flex items-center space-x-10">
            {NAV_ITEMS.map((item) => (
              <li key={item.id}>
                <a 
                  href={`#${item.id}`}
                  onClick={(e) => scrollToSection(e, item.id)}
                  className={`text-[11px] font-bold uppercase tracking-widest transition-all hover:text-emerald-600 py-2 ${
                    activeSection === item.id ? 'text-emerald-600' : 'text-slate-800'
                  }`}
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center space-x-3 md:space-x-4">
          <a 
            href="#offer" 
            onClick={(e) => scrollToSection(e, 'offer')}
            className="bg-slate-900 text-white text-[10px] md:text-xs font-bold uppercase tracking-widest px-4 md:px-6 py-2.5 rounded-full hover:bg-slate-800 transition-all shrink-0 active:scale-95"
          >
            Book Now
          </a>
          
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 text-slate-900 hover:bg-slate-50 rounded-lg transition-colors"
            aria-label="Toggle Menu"
          >
            {isMenuOpen ? (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
            ) : (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7"/></svg>
            )}
          </button>
        </div>
      </div>

      <div className={`lg:hidden absolute top-full left-0 right-0 bg-white border-b border-slate-100 shadow-xl transition-all duration-300 overflow-hidden ${isMenuOpen ? 'max-h-[400px] opacity-100' : 'max-h-0 opacity-0'}`}>
        <nav className="py-6 px-4">
          <ul className="space-y-4">
            {NAV_ITEMS.map((item) => (
              <li key={item.id}>
                <button 
                  onClick={(e) => scrollToSection(e, item.id, () => setIsMenuOpen(false))}
                  className={`w-full text-left text-sm font-bold uppercase tracking-widest py-3 border-b border-slate-50 ${
                    activeSection === item.id ? 'text-emerald-600' : 'text-slate-800'
                  }`}
                >
                  {item.label}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
};
