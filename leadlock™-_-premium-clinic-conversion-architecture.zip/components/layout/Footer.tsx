
import React from 'react';
import { Reveal } from '../ui/Reveal';

export const Footer: React.FC = () => {
  return (
    <footer className="py-24 px-6 text-center bg-slate-50 border-t border-slate-200">
      <Reveal className="max-w-[800px] mx-auto space-y-8">
         <p className="text-slate-900 text-4xl font-serif italic font-bold tracking-tighter">LEADLOCK™</p>
         <p className="text-slate-800 text-[10px] tracking-[0.6em] font-bold uppercase border-y border-slate-200 py-4 inline-block">Surgical Conversion Architecture</p>
         <p className="text-slate-700 text-sm font-semibold max-w-sm mx-auto leading-relaxed italic">Engineered for elite practices that prioritize patient intent and clinical revenue stability.</p>
         <div className="pt-8 text-slate-500 text-[10px] font-bold tracking-widest">© 2024 LEADLOCK SYSTEMS. ALL RIGHTS RESERVED.</div>
      </Reveal>
    </footer>
  );
};
